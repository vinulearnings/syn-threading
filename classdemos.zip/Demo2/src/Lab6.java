
public class Lab6 {

	public static void main(String[] args) {
		Runnable run1 = ()->{
			try { 	Thread.sleep( (long)(Math.random()*1000));} catch (InterruptedException e) { }
				System.out.println("Run1 from" + Thread.currentThread().getName());
		};
		Runnable run2 = ()->{
			for(int i = 0;i < 5;i++){
			try { 	Thread.sleep( (long)(Math.random()*100));} catch (InterruptedException e) { }
				System.out.println("Run2" + i + "  " +  Thread.currentThread().getName());
		}
		};
		
		Thread t1 = new Thread( run1);
		t1.setDaemon(true);
		t1.start();
		Thread t2 = new Thread( run1);
		t2.setDaemon(true);
		
		t2.start();
		Thread t3 = new Thread( run1);
		t3.setDaemon(true);
		t3.start();
	
	}

}
