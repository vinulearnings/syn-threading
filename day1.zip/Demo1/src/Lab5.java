import java.util.Scanner;

class Lab5Support extends Thread{
	private String name;
	
	public Lab5Support(String name) {
		 this.name =name;
	}
	@Override
	public void run() {
		for (int i = 0; i< 99900;i++){
			System.out.print(name);
			if (i % 80 ==0)
					System.out.println();
		}
	}
}
public class Lab5 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a number to continue..");
		scanner.nextInt();
		Lab5Support t1 = new Lab5Support(".");
		t1.setName("t1");
		t1.setPriority(Thread.MAX_PRIORITY);
		
		Lab5Support t2 = new Lab5Support("-");
		t2.setName("t2");
		Lab5Support t3 = new Lab5Support("+");
		t3.setName("t3");
		t1.start();
		t2.start();
		t3.start();
		
		
	}

}
