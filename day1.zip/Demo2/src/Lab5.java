
public class Lab5 {

	public static void main(String[] args) {
		Runnable run1 = ()->{
			try { 	Thread.sleep( (long)(Math.random()*1000));} catch (InterruptedException e) { }
				System.out.println("Run1 from" + Thread.currentThread().getName());
		};
		Runnable run2 = ()->{
			for(int i = 0;i < 5;i++){
			try { 	Thread.sleep( (long)(Math.random()*100));} catch (InterruptedException e) { }
				System.out.println("Run2" + i + "  " +  Thread.currentThread().getName());
		}
		};
		ThreadGroup tgroup1 = new ThreadGroup("Run1");
		Thread t1 = new Thread(tgroup1, run1);
		t1.start();
		Thread t2 = new Thread(tgroup1, run1);
		t2.start();
		Thread t3 = new Thread(tgroup1, run1);
		t3.start();
		System.out.println("tGroup 1 - current count =" + tgroup1.activeCount());
		Thread t5 = new Thread(run2);
		t5.start();

	}

}
