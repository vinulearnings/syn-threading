import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

class Simple implements Callable<String>{
	@Override
	public String call() throws Exception {
		System.out.println("Call invoked in " + Thread.currentThread().getName());
		Thread.sleep(5000);
		return "hello";
	}
}
class SimpleAdd implements Callable<Integer>{
	private int no1;
	private int no2;
	
	
	public SimpleAdd(int no1, int no2) {
		super();
		this.no1 = no1;
		this.no2 = no2;
	}


	@Override
	public Integer call() throws Exception {
		System.out.println("Call invoked in " + Thread.currentThread().getName() + " with " + no1 + ", " + no2);
		Thread.sleep(1000);
		return no1+no2;
	}
}
public class Lab7 {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		ExecutorService service = Executors.newSingleThreadExecutor();
		Future<String> futurestring = service.submit(new Simple());
		Future<Integer> futureint = service.submit(new SimpleAdd(10,400));
		
		System.out.println("in Main  after invoke before get" + Thread.currentThread().getName());
		System.out.println("FutureString value = " + futurestring.get());
		System.out.println("after get call ...");
		System.out.println("FutureAdd  value = " + futureint.get());
		service.shutdown();
	}

}
